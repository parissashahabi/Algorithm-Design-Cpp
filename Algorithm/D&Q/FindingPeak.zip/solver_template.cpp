#include <bits/stdc++.h>
using namespace std;

inline int get(int i){
    cout << "? " << i << '\n';
    cout.flush();
    int a;
    cin >> a;
    return a;
}

inline void submit(int i){
    cout << "! " << i << '\n';
    cout.flush();
}

int main(){
    int n;
    cin >> n;
    // Write your code here using get and submit functions!
}